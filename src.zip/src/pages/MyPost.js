import React from "react";

function MyPost() {
  const onChange = (event) => {
    console.log(event.target.value, "klljkh");
  };
  return (
    <div id="layoutSidenav_content">
      <h3>
        <i class="fa fa-id-badge" aria-hidden="true"></i>&nbsp; My Posts &nbsp;
        <span class="headInfo">
          (<span>13</span>)
        </span>
      </h3>
      <hr />
      <br />
      <div>
        <table width="100%" cellspacing="0" id="postsTable">
          <thead>
            <tr>
              <td>S No.</td>
              <td>Title</td>
              <td>
                <select value="kk">
                    <option value="aadhaar">Categories</option>                    
                    <option value="aadhaar">Climate Change</option>
                    <option value="aadhaar">Architecture</option>
                    <option value="aadhaar">Business</option>
                    <option value="aadhaar">Conflict</option>
                    <option value="aadhaar">America</option>
                    <option value="aadhaar">Censorship</option>
                    <option value="aadhaar">Climate Change</option>
                </select>
              </td>
              <td>Author</td>
              <td>Status</td>
              <td>
                <select onchange="selectDate(this)">
                  <option value="all">All Dates</option>
                  <option value="2020-04">Apr - 2020</option>
                  <option value="2020-03">Mar - 2020</option>
                  <option value="2020-02">Feb - 2020</option>
                  <option value="2020-01">Jan - 2020</option>
                  <option value="2019-12">Dec - 2019</option>
                  <option value="2019-11">Nov - 2019</option>
                  <option value="2019-10">Oct - 2019</option>
                  <option value="2019-09">Sep - 2019</option>
                  <option value="2019-08">Aug - 2019</option>
                  <option value="2019-07">Jul - 2019</option>
                </select>
              </td>
              <td>Actions</td>
            </tr>
          </thead>
          <tbody id="postsData">
            <tr>
              <td>1</td>
              <td>
                <a
                  target="_blank"
                  href="https://fountainink.in/reportage/born-to-play-the-64"
                >
                  The undefeated
                </a>
              </td>
              <td>
                <a href="../../reportage" target="_blank">
                  Reportage
                </a>
              </td>
              <td>
                <a href="../../author/20" target="_blank">
                  Suresh P. Thomas
                </a>
                <br />
                <a href="../../author/0" target="_blank"></a>
              </td>
              <td>
                <p class="pNotify">
                  <small>Published</small>
                </p>
                <span>by You</span>
              </td>
              <td>
                <small>Sep 12, 2018</small>
              </td>
              <td>
                <a
                  target="_blank"
                  href="./post.php?category=reportage&amp;name=reportage&amp;edit=952"
                >
                  <button title="Edit">
                    <i class="fa fa-pencil" aria-hidden="true"></i>
                  </button>
                </a>
              </td>
            </tr>
            <tr>
              <td>2</td>
              <td>
                <a
                  target="_blank"
                  href="https://fountainink.in/reportage/born-to-play-the-64"
                >
                  The undefeated
                </a>
              </td>
              <td>
                <a href="../../reportage" target="_blank">
                  Reportage
                </a>
              </td>
              <td>
                <a href="../../author/20" target="_blank">
                  Suresh P. Thomas
                </a>
                <br />
                <a href="../../author/0" target="_blank"></a>
              </td>
              <td>
                <p class="pNotify">
                  <small>Published</small>
                </p>
                <span>by You</span>
              </td>
              <td>
                <small>Sep 12, 2018</small>
              </td>
              <td>
                <a
                  target="_blank"
                  href="./post.php?category=reportage&amp;name=reportage&amp;edit=952"
                >
                  <button title="Edit">
                    <i class="fa fa-pencil" aria-hidden="true"></i>
                  </button>
                </a>
              </td>
            </tr>

            <tr>
              <td>3</td>
              <td>
                <a
                  target="_blank"
                  href="https://fountainink.in/reportage/born-to-play-the-64"
                >
                  Live Long Mr. Stark
                </a>
              </td>
              <td>
                <a href="../../reportage" target="_blank">
                    Arts & Literature
                </a>
              </td>
              <td>
                <a href="../../author/20" target="_blank">
                  Monica Jha
                </a>
                <br />
                <a href="../../author/0" target="_blank"></a>
              </td>
              <td>
                <p class="pNotify">
                  <small>Published</small>
                </p>
                <span>by You</span>
              </td>
              <td>
                <small>Feb 22, 2022</small>
              </td>
              <td>
                <a
                  target="_blank"
                  href="./post.php?category=reportage&amp;name=reportage&amp;edit=952"
                >
                  <button title="Edit">
                    <i class="fa fa-pencil" aria-hidden="true"></i>
                  </button>
                </a>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}
export default MyPost;
