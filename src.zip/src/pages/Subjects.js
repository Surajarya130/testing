// import { set } from 'draft-js/lib/EditorState';
import React, { useEffect, useState } from 'react';
// import { Link } from "react-router-dom"
function Subjects() {

    
    const [subjectName, setSubjectName] = useState()

    useEffect(() => {
        async function getUsers() {
          const response = await fetch('https://nameless-peak-43027.herokuapp.com/subject', {
            method: 'GET',
            headers: {
              accept: 'application/json',
            },
          });
    
          const data = await response.json();
          setSubjectName(data)
        }
    
        getUsers();
      }, []);  
      
      if(subjectName === undefined){
        return null;
      }

    


  return (
    <>


    <div id='layoutSidenav_content'>
    <h1>Subjects</h1>
    {
      // console.log(subjectName.data.map((eachSub) => ))
    }
    <div className="subjectNames">

        {
          subjectName.data.map((eachSub) => {
              return(
                <button className='my-1'>{eachSub.name}</button>
              )
          })
        }

    </div>

    

    </div>
    </>
  )
}

export default Subjects