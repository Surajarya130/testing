import React from "react"
import { Link } from "react-router-dom"

function AddNewPost () {
   return (
    <div id="layoutSidenav_content">
  
        <div className="container-fluid px-4">
            <h3 className="mt-4">+ Add New Post</h3>
            <hr/>
            <div className="add__new__post boxes">
                <p style={{opacity: 0.8, paddingTop: 10, paddingLeft: 15, fontSize: 16}}>Choose Category:-</p>
                <div className="d-flex flex-wrap w-100 gap-3">
             <Link to="/edit-post">
                    <div>Edit</div>
                </Link>
                <Link to="/reportage">
                    <div>Reportage</div>
                </Link>
                <Link to="#">
                    <div>Essay</div>
                </Link>
                <Link to="#">
                    <div>Q&mp;A</div>
                </Link>
                <Link to="#">
                    <div>Infographic</div>
                </Link>
                <Link to="#">
                    <div>Photo Story</div>
                </Link>
                <Link to="#">
                    <div>Cartoons</div>
                </Link>
                </div>
            
            </div>
        
    
        </div>
   
</div>
   )
}
export default AddNewPost