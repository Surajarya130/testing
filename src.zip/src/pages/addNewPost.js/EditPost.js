import React, { Component } from "react";
import { EditorState } from "draft-js";
import { Editor } from "react-draft-wysiwyg";
import { Link } from "react-router-dom";

class EditPost extends Component {
  constructor(props) {
    super(props);
    this.state = {
      editorState: EditorState.createEmpty(),
    };
  }

  onEditorStateChange = (editorState) => {
    this.setState({
      editorState,
    });
  };

  render() {
    const { editorState } = this.state;

    return (
      <div>
        <div id="layoutSidenav_content">
          <div className="container" style={{width:"780px"}}>
            <h3>
              <Link to="/add-new-post">
                <i
                  class="fa fa-chevron-left"
                  aria-hidden="true"
                  title="Back to Categories"
                ></i>
              </Link>
              &nbsp; Add Edit
            </h3>
            <hr />
            <div className="newPost">
              <form onSubmit={()=>alert("Added")} action="/my-post">
                <input
                  type="text"
                  name="category"
                  value="Edit"
                  disabled=""
                  title="Cannot be changed"
                  className="input__edit"
                />
                <textarea
                  name="title"
                  placeholder="Title"
                  onkeydown="autoResize(this);"
                  onload="autoResize(this);"
                  onkeypress="return event.charCode != 13"
                  maxlength="54"
                  title="Maximum 54 Characters"
                  required=""
                ></textarea>
                <textarea
                  name="excerpt"
                  placeholder="Excerpt"
                  onkeydown="autoResize(this);"
                  onload="autoResize(this);"
                  onkeypress="return event.charCode != 13"
                  maxlength="196"
                  title="Maximum 196 Characters"
                ></textarea>
                <div className="d-flex justify-content-center flex-wrap align-items-center">
                  <span className="by_text">Select Subject</span>
                  <select name="subject" title="Click to change Subject">
                    <option value="aadhaar">Architecture</option>
                    <option value="aadhaar">Business</option>
                    <option value="aadhaar">Conflict</option>
                    <option value="aadhaar">America</option>
                    <option value="aadhaar">Censorship</option>
                    <option value="aadhaar">Climate Change</option>
                  </select>
                  <br />
                  <span className="by_text">Add Topic</span>
                  <select name="author" title="Click to change Subject">
                    <option value="">Film</option>
                    <option value="aadhaar">Series</option>
                    <option value="aadhaar">Tedtalk</option>
                  </select>

                  <i class="dot"></i>
                  <span className="by_text">by</span>
                  <select name="author" title="Click to change Subject">
                    <option value="">Alia Allana</option>
                    <option value="aadhaar">Sourav</option>
                    <option value="aadhaar">Monica</option>
                  </select>
                  <i class="dot"></i>
                  <input
                    type="date"
                    name="date"
                    title="Change Date"
                    value="2022-01-30"
                  ></input>
                </div>
                <div className="text-left pt-2">
                {/* <Editor
                  editorState={editorState}
                  wrapperClassName="rich-editor demo-wrapper"
                  editorClassName="demo-editor"
                  onEditorStateChange={this.onEditorStateChange}
                  placeholder="Type post content here..."
                /> */}
                </div>

                <label for="myfile">Select main Image:</label>
                <input type="file" id="myfile" name="myfile"></input>    
                <br />
                <label htmlFor="quote">Quote of the news</label>
                <textarea name="" id="" cols="30" rows="10"  style={{border:"1px solid", height:"100px", textAlign:"left"}}></textarea>
                <textarea id="w3review" name="w3review" rows="20" cols="50" style={{border:"1px solid", height:"200px", textAlign:"left"}}>
                </textarea>
                  <label for="myfile">Select image two:</label>
                  <input type="file" id="myfile" name="myfile" className="my-3"></input>
                  <br />  
                  <label for="myfile">Select image Three:</label>
                  <input type="file" id="myfile" name="myfile"></input>    
                  <br />
                  <label htmlFor="imageThree">Write caption for image</label>
                  <input type="text" placeholder="Caption" />            
                <br/>

                <div className="btn-wrap d-flex justify-content-center align-items-baseline gap-3 my-3">
                  <button className="save" >Save as Draft</button>
                  <button id="submitButton" >Publish</button>

                </div>
              </form>
          
            </div>
          </div>
        </div>
    
      </div>
    );
  }
}

export default EditPost;

