import React, { Component } from "react";
import { EditorState } from "draft-js";
import { Editor } from "react-draft-wysiwyg";
import { Link } from "react-router-dom";
import ReportageUploadArea from "./ReportageUploadArea";

class Reportage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      editorState: EditorState.createEmpty(),
    
        // options: [
        //     {
        //       isoCode: 'Select…',
        //       countrycode: '+91',
        //     },
        //     {
        //         isoCode: 'A',
        //         countrycode: '+7',
        //     },
        //     {
        //         isoCode: 'B',
        //         countrycode: '+0',
        //     },
        //     {
        //         isoCode: 'C',
        //         countrycode: '+77',
        //     },
        //   ],
        //   value: '?',
        //   inputValue: "",
        //   country : ""
    }
  }

  onEditorStateChange = (editorState) => {
    this.setState({
      editorState,
    });
  };
//   filter = () => {
//       this.state.options.map((ele) => (
//           ele.countrycode === this.state.value ?
//           this.setState({country : ele.countrycode}) : console.log("not")
//       ))
//   }
//   handleChange = (event) => {
//     this.setState({ value: event.target.value });
//     console.log(event.target.value, "eee")
//   };


  render() {
    const { editorState } = this.state;
    // const { options, value } = this.state;
    // console.log(this.state.country , "lljh")
    return (
      <div>
        <div id="layoutSidenav_content">
          <div className="container">
            <h3>
              <Link to="/add-new-post">
                <i
                  class="fa fa-chevron-left"
                  aria-hidden="true"
                  title="Back to Categories"
                ></i>
              </Link>
              &nbsp; Add Reportage
            </h3>
            <hr />
            {/* <select onChange={this.handleChange} value={value}>
          {options.map(item => (
            <option key={item.countrycode} value={item.countrycode}>
              {item.isoCode}
            </option>
          ))}
        </select>
        <input type="text" defaultValue={this.state.value} onChange={(e) => {
            this.setState({inputValue: e.target.value})
            this.filter()
        }}/>
        <p>{this.state.value}</p> */}
            <div className="newPost">
              <form>
                <input
                  type="text"
                  name="category"
                  value="Edit"
                  disabled=""
                  title="Cannot be changed"
                  className="input__edit"
                />
                <textarea
                  name="title"
                  placeholder="Title"
                  onkeydown="autoResize(this);"
                  onload="autoResize(this);"
                  onkeypress="return event.charCode != 13"
                  maxlength="54"
                  title="Maximum 54 Characters"
                  required=""
                ></textarea>
                <textarea
                  name="excerpt"
                  placeholder="Excerpt"
                  onkeydown="autoResize(this);"
                  onload="autoResize(this);"
                  onkeypress="return event.charCode != 13"
                  maxlength="196"
                  title="Maximum 196 Characters"
                ></textarea>
                <div className="d-flex flex-column align-items-center gap-2">
                <div className="d-flex justify-content-center flex-wrap align-items-center">
                  <select name="subject" title="Click to change Subject">
                    <option value="">No Subject</option>
                    <option value="aadhaar">Aadhaar</option>
                  </select>
                  <i class="dot"></i>
                  <span className="by_text">by</span>
                  <select name="author" title="Click to change Subject">
                    <option value="">Fountain Ink</option>
                    <option value="aadhaar">Aadhaar</option>
                  </select>
                  <i class="dot"></i>
                  <span className="by_text">&</span>
                  <select name="author" title="Click to change Subject">
                    <option value="">None</option>
                    <option value="aadhaar">Aadhaar</option>
                  </select>
                  <br/>
                 
                </div>
                <input
                    type="date"
                    name="date"
                    title="Change Date"
                    value="2022-01-30"
                  ></input>
                </div>
                
                    <ReportageUploadArea/>
             
                <div className="text-left pt-2">
                <Editor
                  editorState={editorState}
                  wrapperClassName="rich-editor demo-wrapper"
                  editorClassName="demo-editor"
                  onEditorStateChange={this.onEditorStateChange}
                  placeholder="Type post content here..."
                  
                />
                </div>
                <br/>
                <div className="btn-wrap d-flex justify-content-center align-items-baseline gap-3">
                  <button className="save" >Save as Draft</button>
                  <button id="submitButton" >Publish</button>

                </div>
              </form>
          
            </div>
          </div>
        </div>
    
      </div>
    );
  }
}

export default Reportage;

