import React from 'react'

function Categories() {
  return (
    <div id='layoutSidenav_content'>
    <h1>Categories</h1>
    <button className="my-2">Edit</button>
    <button className="my-2">Popular</button>
    <button className="my-2">Opinions</button>
    <button className="my-2">Essay Series</button>
    <button className="my-2">Essay Of The Month</button>
    <button className="my-2">Photo Story</button>
    <button className="my-2">Lates</button>
    <button className="my-2">Video/Audio Podcast</button>
    </div>
  )
}

export default Categories