import React from "react";
import { Link } from "react-router-dom";

function Dashboard() {
  return (


    <div id="layoutSidenav_content">
      <div className="">
        <h3>
          <i className="fa fa-tachometer" aria-hidden="true"></i>&nbsp; Dashboard
        </h3>
        <hr />
        <div className="dashboardStickers">
          <div>
            <h1>
              <span id="visitors">722,176</span>
              <i className="fa fa-thumbs-o-up" aria-hidden="true"></i>
            </h1>
            <p>Visitors</p>
          </div>
          <div>
            <h1>
              2,633,059<i className="fa fa-eye" aria-hidden="true"></i>
            </h1>
            <p>Reads</p>
          </div>
          <div>
            <h1>
              1,300<i className="fa fa-heart-o" aria-hidden="true"></i>
            </h1>
            <p>Likes</p>
          </div>
          <div>
            <h1>
              528,506<i className="fa fa-chain-broken" aria-hidden="true"></i>
            </h1>
            <p>Old Links handled</p>
          </div>
        </div>
        <div className="dashboardStickers">
    <div>
      <Link to="./subscription/">
        <h1>
          0<i className="fa fa-calendar" aria-hidden="true"></i>
        </h1>
        <p>Subscribers</p>
      </Link>
    </div>
    <div>
      <Link to="./orders/">
        <h1>
          50<i className="fa fa-shopping-cart blink" aria-hidden="true" title="Orders awaiting shipping"><span>7</span></i>        </h1>
        <p>Orders</p>
      </Link>
    </div>
    <div>
      <Link to="./newsletter/">
        <h1>
          1,378<i className="fa fa-newspaper-o" aria-hidden="true"></i>
        </h1>
        <p>Newsletter</p>
      </Link>
    </div>
    <div>
      <Link to="./digital-marketing/">
        <h1>
          209<i className="fa fa-compress" aria-hidden="true"></i>
        </h1>
        <p>Short URLs</p>
      </Link>
    </div>
  </div>
  <div className="dashboardBanner">
    <div>
      <h5><i className="fa fa-bell-o" aria-hidden="true"></i>&nbsp; Recent Activity</h5>
      <div className="dashboardActivity">
      </div>
    </div>
    <div><h5><i className="fa fa-refresh" aria-hidden="true"></i>&nbsp; Updates</h5>
      <div className="dashboardActivity">
        <b>February 04, 2020, 5:00pm</b>

      </div>
    </div>
  </div>
      </div>
    </div>

  );
}
export default Dashboard;
