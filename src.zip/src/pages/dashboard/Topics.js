import React from 'react'

function Topics() {
  return (
    <div id='layoutSidenav_content'>
    <h1>Topics</h1>

        <div class="add__new__post boxes">

        </div>    
    </div>
  )
}

export default Topics