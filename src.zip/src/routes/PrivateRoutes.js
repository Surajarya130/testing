import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route
} from "react-router-dom";
import AddAuthor from "../pages/AddAuthor";
import AddNewPost from "../pages/addNewPost.js/AddNewPost";
import  EditPost  from "../pages/addNewPost.js/EditPost";
import Reportage from "../pages/addNewPost.js/Reportage";
import Authors from "../pages/dashboard/Authors";
import Categories from "../pages/dashboard/Categories";
// import EditPost from "../pages/addNewPost.js/editPost";
import Dashboard from "../pages/dashboard/Dashboard";
import Topics from "../pages/dashboard/Topics";
import Login from "../pages/Login";
import MyPost from "../pages/MyPost";
import Subjects from "../pages/Subjects";

export default function PrivateRoutes() {
    return (
        // <Router>
          <Routes>
            <Route exact path="/" element={<Login />}/>
            <Route exact path="/dashboard" element={<Dashboard/>}/>
            <Route exact path="/authors" element={<Authors />}/>
            <Route exact path="/add-author" element={<AddAuthor />}/>
            <Route exact path="/categories" element={<Categories />}/>
            <Route exact path="/topics" element={<Topics />}/>
            <Route exact path="/add-new-post" element ={<AddNewPost/>}/>
            <Route exact path="/edit-post" element={<EditPost/>}/>
            <Route exact path="/reportage" element={<Reportage/>}/>
            <Route exact path="/my-post" element={<MyPost/>}/>
            <Route exact path="/subjects" element={<Subjects/>}/>
            {/* <Route exact path="/topics" element={<Subjects/>}/>
             */}

          </Routes>
      // </Router>

    )
}