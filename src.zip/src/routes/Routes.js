import React from "react";
import PrivateRoutes from "./PrivateRoutes";

export default function Routes () {
    return (
        <PrivateRoutes/>
    )
}